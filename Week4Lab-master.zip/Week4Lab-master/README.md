# Week4Lab
Week 4 discussion

clear
echo "This is a test"
ls -la
echo "I need to upload this new line"

